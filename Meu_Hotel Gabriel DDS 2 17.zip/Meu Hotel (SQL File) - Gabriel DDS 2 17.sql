CREATE DATABASE meuhotel;

USE meuhotel;

CREATE TABLE clientes (
    cpf VARCHAR(11) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    data_nascimento DATE NOT NULL
);

CREATE TABLE estadias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cpf_cliente VARCHAR(11) NOT NULL,
    data_checkin DATE NOT NULL,
    data_checkout DATE,
    quarto VARCHAR(10) NOT NULL,
    FOREIGN KEY (cpf_cliente) REFERENCES clientes(cpf)
);

CREATE TABLE reclamacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cpf_cliente VARCHAR(11) NOT NULL,
    descricao TEXT NOT NULL,
    data_reclamacao DATE NOT NULL,
    FOREIGN KEY (cpf_cliente) REFERENCES clientes(cpf)
);

-- Inserir mais dados de exemplo para clientes
INSERT INTO clientes (cpf, nome, email, telefone, data_nascimento) VALUES
('33344455566', 'Carla Lima', 'carla@gmail.com', '11955555555', '1987-07-15'),
('44455566677', 'Rafaela Pereira', 'rafaela@gmail.com', '11944444444', '1995-04-20'),
('55566677788', 'Marcos Santos', 'marcos@gmail.com', '11933333333', '1983-08-25'),
('66677788899', 'Luiz Fernandes', 'luiz@gmail.com', '11922222222', '1990-11-30'),
('77788899900', 'Camila Oliveira', 'camila@gmail.com', '11911111111', '1988-10-05'),
('88899900011', 'Felipe Almeida', 'felipe@gmail.com', '11900000000', '1982-12-10'),
('99900011122', 'Juliana Costa', 'juliana@gmail.com', '1199999999', '1984-09-18'),
('00011122233', 'Mariana Souza', 'mariana@gmail.com', '1198888888', '1993-06-22'),
('11122233344', 'Pedro Santos', 'pedro@gmail.com', '1197777777', '1985-05-05'), -- Cliente repetido
('22233344455', 'Ana Souza', 'ana@gmail.com', '1196666666', '1982-03-10'); -- Cliente repetido


-- Inserir mais dados de exemplo para estadias
INSERT INTO estadias (cpf_cliente, data_checkin, data_checkout, quarto) VALUES
('33344455566', '2024-04-01', '2024-04-10', '102'),
('44455566677', '2024-04-01', '2024-04-05', '124'),
('55566677788', '2024-05-10', '2024-05-15', '202'),
('66677788899', '2024-06-15', NULL, '302'), -- Estadia em andamento, sem data de checkout
('77788899900', '2024-07-01', '2024-07-10', '103'),
('88899900011', '2024-08-01', '2024-08-08', '125'),
('99900011122', '2024-09-10', '2024-09-20', '203'),
('00011122233', '2024-10-15', '2024-10-25', '303'),
('11122233344', '2024-11-01', '2024-11-05', '104'),
('22233344455', '2024-12-01', NULL, '126'); -- Estadia em andamento, sem data de checkout

-- Inserir mais dados de exemplo para reclamações
INSERT INTO reclamacoes (cpf_cliente, descricao, data_reclamacao) VALUES
('33344455566', 'Houve um problema com a limpeza do quarto.', '2024-04-08'),
('44455566677', 'Problemas com o ar condicionado do quarto.', '2024-04-03'),
('55566677788', 'Falta de água quente no chuveiro.', '2024-05-12'),
('66677788899', 'Barulho excessivo durante a noite.', '2024-06-18'),
('77788899900', 'Demora no atendimento da recepção.', '2024-07-05'),
('88899900011', 'Problema com a fechadura da porta do quarto.', '2024-08-03'),
('99900011122', 'Wi-Fi com sinal fraco no quarto.', '2024-09-15'),
('00011122233', 'Problemas com a qualidade do café da manhã.', '2024-10-20'),
('11122233344', 'Inconvenientes com a reserva do quarto.', '2024-11-03'),
('22233344455', 'Problemas com a cobrança indevida.', '2024-12-05');



